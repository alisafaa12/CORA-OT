"""
stress.py - round-3 stress tests of the synthetic comparison (Section 8.5, Appendix B).

E6  Ranking validity under misspecified ground truth:
      A0  case A, nominal truth (as in Table 12)
      A1  case A, true value ratio varied per instance (rho_true ~ U[3, 8]; model keeps 5)
      A2  case A, topology error (15% of arcs absent in truth, 4+4 hidden arcs added)
      A3  case A, both errors
      B0  randomly generated cases (new topology every instance), nominal truth
      B3  randomly generated cases, both errors
    Methods: 5x5 matrix, CVSS-only, FAIR-style (one-hop / multi-hop),
             BAG-style (one-hop / multi-hop), CORA-OT no-cascade, static, dynamic.
E7  Calibration under misspecified evidence generators (+ Brier decomposition).
E8  Federated-summary inference test (leakage).
E9  Power of the planned testbed comparison.

All data synthetic, seeds fixed. Writes results/stress_*.json
"""
import json, os, heapq
import numpy as np
from scipy.stats import kendalltau, t as tdist, nct
import cora_model as cm
import case_study as cs

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)


# ============================================================ case container
class Case:
    def __init__(self, nodes, att, con, ag, impact, scen, omega):
        self.nodes = nodes                      # (id, label, owner, kind)
        self.idx = {n[0]: i for i, n in enumerate(nodes)}
        self.N = len(nodes)
        self.Wa0 = np.zeros((self.N, self.N)); self.Wc0 = np.zeros((self.N, self.N))
        for a, b, w in att: self.Wa0[self.idx[a], self.idx[b]] = w
        for a, b, w in con: self.Wc0[self.idx[a], self.idx[b]] = w
        self.AG = [([self.idx[m] for m in ms], self.idx[j], w) for ms, j, w in ag]
        self.I0 = np.array([impact[n[0]] for n in nodes], float)
        # scenario: dict(id, entry[idx], targets[idx], rate, cvss, local idx, nonmal, sev)
        self.S = scen
        self.omega = np.asarray(omega)
        self.partner = {i for i, n in enumerate(nodes) if n[2] != "Operator"}
        self.mal = [k for k, s in enumerate(scen) if not s["nonmal"]]
        self.attack_nodes = [i for i, n in enumerate(nodes) if n[3] != "Function"]


def case_A():
    sc = []
    for sid, title, entry, targets, rate, cvss, local in cs.SCENARIOS:
        nonmal = sid in ("S5", "S8")
        sc.append(dict(id=sid, entry=[cs.IDX[x] for x in entry], targets=[cs.IDX[x] for x in targets],
                       rate=rate, cvss=cvss, local=cs.IDX[local], nonmal=nonmal,
                       sev=cs.MATRIX_SEVERITY.get(sid)))
    return Case(cs.NODES, cs.ATT_ARCS, cs.CON_ARCS, cs.AND_GROUPS, cs.IMPACT, sc, cs.OMEGA)


def random_case(rng):
    """Layered IT/OT topology with an OT supplier, telecom redundancy and an external function."""
    U = lambda a, b: float(rng.uniform(a, b))
    R = lambda a, b: int(rng.integers(a, b + 1))
    it = [f"IT{i}" for i in range(R(6, 10))]
    dmz = [f"DMZ{i}" for i in range(R(2, 4))]
    ot = [f"OT{i}" for i in range(R(4, 8))]
    sup = [f"SUP{i}" for i in range(R(1, 2))]
    tel, rad = "TEL", "RAD"
    fun = ["FC", "FM", "FS", "FX"]                     # control, monitoring, customer service, external
    nodes = ([(n, n, "Operator", "IT") for n in it] + [(n, n, "Operator", "IT/OT") for n in dmz] +
             [(n, n, "Operator", "OT") for n in ot] + [(n, n, "Supplier", "IT") for n in sup] +
             [(tel, tel, "Telco", "Comms"), (rad, rad, "Operator", "Comms")] +
             [("FC", "FC", "Operator", "Function"), ("FM", "FM", "Operator", "Function"),
              ("FS", "FS", "Operator", "Function"), ("FX", "FX", "Partner", "Function")])
    att, con = {}, {}
    def add(d, a, b, lo, hi):
        if a != b and (a, b) not in d: d[(a, b)] = round(U(lo, hi), 2)
    for a in it:
        for b in rng.choice(it, R(1, 2), replace=False): add(att, a, b, 0.2, 0.6)
    for a in rng.choice(it, R(2, 3), replace=False): add(att, a, rng.choice(dmz), 0.3, 0.7)
    for a in dmz:
        for b in rng.choice(ot, R(1, 2), replace=False): add(att, a, b, 0.3, 0.7)
    for i in range(len(ot) - 1):
        add(att, ot[i], ot[i + 1], 0.2, 0.6)
        if rng.random() < 0.4: add(att, ot[i + 1], ot[i], 0.2, 0.5)
    for s in sup:
        for b in rng.choice(dmz + ot, R(1, 2), replace=False): add(att, s, b, 0.3, 0.6)
    impact = {}
    for n in it: impact[n] = [0, R(0, 2), R(0, 2), 0, R(0, 2), R(0, 2)]
    for n in dmz: impact[n] = [0, R(0, 2), R(0, 2), 0, R(0, 1), 0]
    for n in ot:
        impact[n] = [5 if rng.random() < 0.15 else R(0, 2), R(1, 3), R(1, 2), R(0, 1), R(0, 2), 0]
    for n in sup: impact[n] = [0, 0, R(0, 1), 0, 0, 0]
    impact[tel] = [0, 1, 1, 0, 0, 0]; impact[rad] = [0, 0, 0, 0, 0, 0]
    impact["FC"] = [R(2, 4), R(4, 5), R(3, 4), R(0, 2), R(3, 4), R(3, 5)]
    impact["FM"] = [R(0, 2), R(2, 3), R(1, 3), 0, R(1, 2), R(0, 2)]
    impact["FS"] = [0, R(1, 3), R(2, 3), 0, R(2, 3), R(1, 3)]
    impact["FX"] = [R(1, 4), R(2, 5), R(1, 3), R(0, 3), R(1, 3), R(2, 5)]
    for n in ot:
        if rng.random() < 0.6: add(con, n, "FC", 0.4, 0.9)
        if rng.random() < 0.3: add(con, n, "FM", 0.3, 0.7)
    if not any(b == "FC" for (_, b) in con): add(con, ot[0], "FC", 0.6, 0.9)
    for n in dmz:
        if rng.random() < 0.5: add(con, n, "FM", 0.3, 0.6)
    for n in it:
        if rng.random() < 0.4: add(con, n, "FS", 0.3, 0.9)
        if rng.random() < 0.2: add(con, n, rng.choice(it), 0.3, 0.7)
    add(con, "FC", "FX", 0.4, 0.8)
    add(con, tel, rng.choice(ot), 0.3, 0.5)
    ag = [((tel, rad), str(rng.choice(ot)), 0.85)]
    case_tmp = Case(nodes, [(a, b, w) for (a, b), w in att.items()], [(a, b, w) for (a, b), w in con.items()],
                    ag, impact, [], [0.30, 0.25, 0.15, 0.10, 0.10, 0.10])
    idx = case_tmp.idx
    scen = []
    entries = it + sup
    for k in range(6):
        e = [idx[str(rng.choice(entries))]]
        pi0 = np.zeros(case_tmp.N); pi0[e] = 1
        reach = cm.propagate(case_tmp.Wa0, pi0, 1.0)
        cand = [j for j in range(case_tmp.N) if reach[j] > 0.05 and j not in e
                and nodes[j][3] != "Function"]
        tgt = [int(rng.choice(cand))] if cand else e
        scen.append(dict(id=f"S{k+1}", entry=e, targets=tgt, rate=U(0.1, 0.6), cvss=round(U(4, 10), 1),
                         local=e[0], nonmal=False, sev=None))
    o = idx[str(rng.choice(ot))]
    scen.append(dict(id="S7", entry=[o], targets=[o], rate=U(0.05, 0.15), cvss=0.0, local=o, nonmal=True,
                     sev=int(max(1, case_tmp.I0[o].max()))))
    scen.append(dict(id="S8", entry=[idx[tel], idx[rad]], targets=[idx[tel], idx[rad]], rate=U(0.03, 0.1),
                     cvss=0.0, local=idx[tel], nonmal=True, sev=2))
    case_tmp.S = scen
    case_tmp.mal = [k for k, s in enumerate(scen) if not s["nonmal"]]
    return case_tmp


# ============================================================ truth and simulator
def live_edge(W, start, n_samp, rng, ag=None):
    n = W.shape[0]; src, dst = np.nonzero(W)
    act = rng.random((n_samp, len(src))) < W[src, dst][None, :]
    agact = [rng.random(n_samp) < w for _, _, w in ag] if ag else []
    imp = np.repeat(start[None, :], n_samp, axis=0).copy()
    for _ in range(n):
        new = imp.copy(); hit = imp[:, src] & act
        for k in range(len(src)): new[:, dst[k]] |= hit[:, k]
        for g, (m, j, w) in enumerate(ag or []): new[:, j] |= imp[:, m].all(axis=1) & agact[g]
        if (new == imp).all(): break
        imp = new
    return imp


def sample_truth(C, rng, ratio_mode="fixed", topo_err=False, sig=0.3, campaign_p=0.25):
    Wa = np.clip(C.Wa0 * np.exp(rng.normal(0, sig, C.Wa0.shape)), 0, 0.95) * (C.Wa0 > 0)
    Wc = np.clip(C.Wc0 * np.exp(rng.normal(0, sig, C.Wc0.shape)), 0, 0.95) * (C.Wc0 > 0)
    if topo_err:
        for W in (Wa, Wc):
            ii, jj = np.nonzero(W)
            drop = rng.random(len(ii)) < 0.15
            W[ii[drop], jj[drop]] = 0.0
        nonfun = C.attack_nodes
        for _ in range(4):                       # hidden attack paths
            a, b = rng.choice(nonfun, 2, replace=False)
            if Wa[a, b] == 0: Wa[a, b] = rng.uniform(0.2, 0.6)
        for _ in range(4):                       # hidden functional dependencies
            a = rng.choice(nonfun); b = rng.integers(0, C.N)
            if a != b and Wc[a, b] == 0: Wc[a, b] = rng.uniform(0.2, 0.6)
    NS = len(C.S)
    rates = np.array([s["rate"] for s in C.S]) * np.exp(rng.normal(0, sig, NS))
    camp = np.zeros(NS, bool); camp[C.mal] = rng.random(len(C.mal)) < campaign_p
    ratio = 5.0 if ratio_mode == "fixed" else float(rng.uniform(3, 8))
    lvl = C.I0
    V = np.where(lvl > 0, 10.0 * ratio ** (lvl - 1), 0.0)
    mult = C.omega * 6 * np.exp(rng.normal(0, 0.3, 6))
    noise = np.exp(rng.normal(0, 0.4, lvl.shape))
    L = V * noise * mult[None, :]
    return dict(Wa=Wa, Wc=Wc, rates=rates, true_rates=rates * np.where(camp, 4.0, 1.0), campaign=camp,
                node_loss=L.sum(axis=1), lvl_noise=np.log(noise) / np.log(ratio), ratio=ratio)


def true_eal(C, tr, rng, n_samp=400):
    out = np.zeros(len(C.S))
    for k, s in enumerate(C.S):
        e = np.zeros(C.N, bool); e[s["entry"]] = True
        if s["nonmal"]:
            succ = np.ones(n_samp, bool)
        else:
            succ = live_edge(tr["Wa"], e, n_samp, rng)[:, s["targets"]].any(axis=1)
        tm = np.zeros(C.N, bool); tm[s["targets"]] = True
        imp = live_edge(tr["Wc"], tm, n_samp, rng, C.AG)
        out[k] = tr["true_rates"][k] * np.mean(succ * (imp.astype(float) @ tr["node_loss"]))
    return out


def elicit(C, tr, rng, sig=0.5):
    """Assessors know the NOMINAL structure only; weights on believed arcs are noisy truths
    (or noisy nominal values where the arc does not exist in truth)."""
    base_a = np.where(tr["Wa"] > 0, tr["Wa"], C.Wa0) * (C.Wa0 > 0)
    base_c = np.where(tr["Wc"] > 0, tr["Wc"], C.Wc0) * (C.Wc0 > 0)
    Wa = np.clip(base_a * np.exp(rng.normal(0, sig, base_a.shape)), 0, 0.95)
    Wc = np.clip(base_c * np.exp(rng.normal(0, sig, base_c.shape)), 0, 0.95)
    rates = tr["rates"] * np.exp(rng.normal(0, sig, len(C.S)))
    I = np.clip(np.round(C.I0 + tr["lvl_noise"] + rng.normal(0, sig, C.I0.shape)), 0, 5) * (C.I0 > 0)
    return dict(Wa=Wa, Wc=Wc, rates=rates, I=I)


def evidence(C, tr, rng):
    ev = {}
    for k in C.mal:
        n = rng.poisson(2.0 if tr["campaign"][k] else 0.4)
        cl = []
        for _ in range(n):
            w = cm.evidence_weight(rng.uniform(0.5, 0.95), 0.9, cm.freshness(rng.uniform(0, 120), 90),
                                   rng.uniform(0.5, 1.0))
            c = [w * cm.ell("moderate")]
            if rng.random() < 0.3: c += c * int(rng.integers(1, 3))
            cl.append(c)
        ev[k] = cl
    return ev


# ============================================================ assessment methods
V_NOM = np.array([0, 10, 50, 250, 1250, 6250], float)


def reach_set(W, start):
    seen, stack = set(start), list(start)
    while stack:
        i = stack.pop()
        for j in np.nonzero(W[i] > 0)[0]:
            if j not in seen: seen.add(j); stack.append(j)
    return sorted(seen)


def best_path(W, start):
    """max-product path weight from the start set to every node (Dijkstra on -log w)."""
    n = W.shape[0]; best = np.zeros(n); h = []
    for s in start: best[s] = 1.0; heapq.heappush(h, (-1.0, s))
    while h:
        nb, i = heapq.heappop(h); nb = -nb
        if nb < best[i]: continue
        for j in np.nonzero(W[i] > 0)[0]:
            v = nb * W[i, j]
            if v > best[j]: best[j] = v; heapq.heappush(h, (-v, j))
    return best


METHODS = ["5x5 matrix", "CVSS-only", "FAIR-style (one-hop)", "FAIR-style (multi-hop)",
           "BAG-style (one-hop)", "BAG-style (multi-hop)", "CORA-OT no-cascade",
           "CORA-OT static", "CORA-OT dynamic"]


def scores(C, el, ev, rng, gamma=0.8):
    Wa, Wc, I, rates = el["Wa"], el["Wc"], el["I"], el["rates"]
    d = cm.direct_consequence(I, C.omega, (0,))
    money = V_NOM[I.astype(int)].sum(axis=1)
    out = {m: np.zeros(len(C.S)) for m in METHODS}
    for k, s in enumerate(C.S):
        e, t = s["entry"], s["targets"]
        if s["nonmal"]:
            p0 = 1 - np.exp(-rates[k]); sus = 1.0
        else:
            p0, _ = cm.scenario_probability(rates[k], Wa, e, t)
            sus = max(Wa[i].max() for i in e)
        lk = int(np.digitize(rates[k], [0.05, 0.1, 0.25, 0.5]) + 1)
        imp = s["sev"] if s["sev"] is not None else max(1, int(I[s["local"]].max()))
        out["5x5 matrix"][k] = lk * imp + 1e-3 * rng.random()
        out["CVSS-only"][k] = s["cvss"] + 1e-3 * rng.random()
        one = sorted(set(t) | {j for i in t for j in range(C.N) if Wc[i, j] > 0.5})
        multi = reach_set(Wc, t)
        bp = best_path(Wc, t)
        lef = rates[k] * sus
        out["FAIR-style (one-hop)"][k] = lef * money[one].sum()
        out["FAIR-style (multi-hop)"][k] = lef * money[multi].sum()
        out["BAG-style (one-hop)"][k] = p0 * money[one].sum()
        out["BAG-style (multi-hop)"][k] = p0 * (bp * money).sum()
        Cs, _ = cm.cascading_consequence(Wc, t, d, gamma, and_groups=C.AG)
        out["CORA-OT no-cascade"][k] = p0 * d[t].sum()
        out["CORA-OT static"][k] = p0 * Cs
        p = cm.update_probability(p0, ev.get(k, []), eta=0.0) if k in ev else p0
        out["CORA-OT dynamic"][k] = p * Cs
    return out


def top3(a, b):
    return len(set(np.argsort(-a)[:3]) & set(np.argsort(-b)[:3])) / 3


def boot(x, rng, B=2000):
    x = np.asarray(x, float); bs = rng.choice(x, (B, len(x))).mean(axis=1)
    return [float(x.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def run_E6(n_inst=200, seed=20261108):
    rng = np.random.default_rng(seed)
    A = case_A()
    conds = {"A0 nominal": ("A", "fixed", False), "A1 value ratio varied": ("A", "vary", False),
             "A2 topology error": ("A", "fixed", True), "A3 both errors": ("A", "vary", True),
             "B0 random cases": ("B", "fixed", False), "B3 random cases, both errors": ("B", "vary", True)}
    res = {}
    for name, (which, rmode, terr) in conds.items():
        tau = {m: [] for m in METHODS}; rec = {m: [] for m in METHODS}
        for it in range(n_inst):
            C = A if which == "A" else random_case(rng)
            tr = sample_truth(C, rng, rmode, terr)
            g = true_eal(C, tr, rng)
            if np.allclose(g, g[0]): continue
            sc = scores(C, elicit(C, tr, rng), evidence(C, tr, rng), rng)
            for m in METHODS:
                tau[m].append(kendalltau(sc[m], g)[0]); rec[m].append(top3(sc[m], g))
        best_base = max(["FAIR-style (multi-hop)", "BAG-style (multi-hop)"], key=lambda m: np.mean(tau[m]))
        res[name] = dict(n=len(tau[METHODS[0]]),
                         methods={m: dict(tau=boot(tau[m], rng), top3=boot(rec[m], rng)) for m in METHODS},
                         best_multihop_baseline=best_base,
                         diff_dynamic_minus_best=boot(np.array(tau["CORA-OT dynamic"]) - np.array(tau[best_base]), rng),
                         diff_static_minus_nocascade=boot(np.array(tau["CORA-OT static"]) - np.array(tau["CORA-OT no-cascade"]), rng))
        print(name, res[name]["n"], {m: round(v["tau"][0], 3) for m, v in res[name]["methods"].items()},
              best_base, [round(x, 3) for x in res[name]["diff_dynamic_minus_best"]], flush=True)
    res["_chance"] = dict(tau=0.0, top3=3 * 3 / 8 / 3)
    json.dump(res, open(f"{OUT}/stress_E6_ranking.json", "w"), indent=1)
    return res


def run_E6b(n_inst=300, seed=99):
    """Ranking cost of each federated disclosure option (case A, nominal truth, CORA-OT dynamic)."""
    rng = np.random.default_rng(seed); C = case_A()
    opts = ["full visibility", "3-bin summaries", "randomised 3-bin", "existence only", "partner arcs omitted"]
    tau = {o: [] for o in opts}
    for _ in range(n_inst):
        tr = sample_truth(C, rng); g = true_eal(C, tr, rng); ev = evidence(C, tr, rng)
        el0 = elicit(C, tr, rng)
        for o in opts:
            el = {k: (v.copy() if hasattr(v, "copy") else v) for k, v in el0.items()}
            for W in (el["Wa"], el["Wc"]):
                for i, j in zip(*np.nonzero(W)):
                    if i in C.partner or j in C.partner:
                        b = int(np.digitize(W[i, j], [0.35, 0.65]))
                        if o == "3-bin summaries": W[i, j] = [0.2, 0.5, 0.8][b]
                        elif o == "randomised 3-bin":
                            W[i, j] = [0.2, 0.5, 0.8][b if rng.random() < 0.6 else int(rng.integers(0, 3))]
                        elif o == "existence only": W[i, j] = 0.5
                        elif o == "partner arcs omitted": W[i, j] = 0.0
            tau[o].append(kendalltau(scores(C, el, ev, rng)["CORA-OT dynamic"], g)[0])
    res = {o: boot(tau[o], rng) for o in opts}
    print(res, flush=True)
    json.dump(res, open(f"{OUT}/stress_E6b_federated.json", "w"), indent=1)
    return res


def run_E6c(n_inst=300, seed=4242):
    """Value-function ablation when the TRUE level ratio is fixed (5) or varied (U[3, 8])."""
    rng = np.random.default_rng(seed); C = case_A(); out = {}
    for mode in ("fixed", "vary"):
        t_ord, t_val = [], []
        for _ in range(n_inst):
            tr = sample_truth(C, rng, mode, False); g = true_eal(C, tr, rng)
            ev = evidence(C, tr, rng); el = elicit(C, tr, rng)
            t_val.append(kendalltau(scores(C, el, ev, rng)["CORA-OT dynamic"], g)[0])
            d_ord = el["I"] @ C.omega; v = []
            for k, s in enumerate(C.S):
                e, t = s["entry"], s["targets"]
                p0 = 1 - np.exp(-el["rates"][k]) if s["nonmal"] else cm.scenario_probability(el["rates"][k], el["Wa"], e, t)[0]
                p = cm.update_probability(p0, ev.get(k, []), 0.0) if k in ev else p0
                v.append(p * cm.cascading_consequence(el["Wc"], t, d_ord, 0.8, and_groups=C.AG)[0])
            t_ord.append(kendalltau(v, g)[0])
        out[mode] = dict(value=boot(t_val, rng), ordinal=boot(t_ord, rng))
    print(out, flush=True)
    json.dump(out, open(f"{OUT}/stress_E6c_valuefunction.json", "w"), indent=1)
    return out


# ============================================================ E7 calibration robustness
def run_E7(n=6000, seed=7):
    rng = np.random.default_rng(seed)
    gens = {"G1 joint validity (model-consistent)": ("prod", 0.85),
            "G2 weakest-link validity": ("min", 0.85),
            "G3 correlated factors (geometric)": ("geo", 0.85),
            "G4 lower item accuracy (0.75)": ("prod", 0.75)}
    rules = ["Static prior", "Naive (duplicates counted)", "Geometric-mean weights, clustered", "CORA-OT update"]
    out = {}
    for gname, (vmode, acc) in gens.items():
        P = {r: [] for r in rules}; Y = []
        for _ in range(n):
            p0 = rng.beta(2, 8); H = rng.random() < p0; Y.append(H)
            items = []
            for _ in range(rng.poisson(4)):
                r, a = rng.uniform(0.5, 1.0), rng.uniform(0.5, 1.0)
                q = rng.choice([0.0, 0.6, 0.9, 1.0], p=[.1, .2, .4, .3]); dlt = cm.freshness(rng.uniform(0, 120), 90)
                f = np.array([r, q, dlt, a])
                v = f.prod() if vmode == "prod" else (f.min() if vmode == "min" else f.prod() ** 0.25)
                sig = (H if rng.random() < acc else (not H)) if rng.random() < v else (rng.random() < 0.5)
                items.append((r, q, dlt, a, 1 if sig else -1, int(rng.integers(1, 3)) if rng.random() < 0.3 else 0))
            L = np.log(0.85 / 0.15)
            def upd(mode, cluster, use_w=True):
                g = []
                for (r, q, dl, a, s, dup) in items:
                    w = cm.evidence_weight(r, q, dl, a, mode) if use_w else 1.0
                    c = [w * s * L] * (1 + dup)
                    g.append(c) if cluster else g.extend([[x] for x in c])
                return cm.update_probability(p0, g, 0.0)
            P["Static prior"].append(p0)
            P["Naive (duplicates counted)"].append(upd("product", False, False))
            P["Geometric-mean weights, clustered"].append(upd("geomean", True))
            P["CORA-OT update"].append(upd("product", True))
        y = np.array(Y, float); res = {}
        for r in rules:
            p = np.array(P[r]); brier = float(np.mean((p - y) ** 2))
            bins = np.clip((p * 10).astype(int), 0, 9); rel = res_ = 0.0; ece = 0.0; ybar = y.mean()
            for b in range(10):
                m = bins == b
                if m.any():
                    w = m.mean(); pb, ob = p[m].mean(), y[m].mean()
                    ece += w * abs(pb - ob); rel += w * (pb - ob) ** 2; res_ += w * (ob - ybar) ** 2
            res[r] = dict(brier=brier, ece=float(ece), reliability=float(rel), resolution=float(res_),
                          uncertainty=float(ybar * (1 - ybar)))
        out[gname] = res
        print(gname, {r: (round(v["brier"], 4), round(v["ece"], 4), round(v["resolution"], 4)) for r, v in res.items()}, flush=True)
    json.dump(out, open(f"{OUT}/stress_E7_calibration.json", "w"), indent=1)
    return out


# ============================================================ E8 federated leakage
def run_E8(n=6000, seed=11):
    """Random partner subgraphs between an in-boundary node (0) and an out-boundary node (1).
    Secrets: (a) large internal estate (>= 8 internal nodes); (b) a single internal point of failure.
    Disclosures: 3-bin summary (CORA-OT default), exact end-to-end weight (50 quantile bins)."""
    rng = np.random.default_rng(seed)
    X3, Xe, Sa, Sb = [], [], [], []
    def reach(W, s, t):
        return t in reach_set(W, [s])
    while len(X3) < n:
        k = int(rng.integers(3, 13)); N = k + 2
        W = np.zeros((N, N)); order = [0] + list(rng.permutation(range(2, N))) + [1]
        for a in range(len(order) - 1):
            for b in range(a + 1, len(order)):
                if rng.random() < (0.55 if b == a + 1 else 0.18): W[order[a], order[b]] = rng.uniform(0.2, 0.9)
        if not reach(W, 0, 1): continue
        pi0 = np.zeros(N); pi0[0] = 1
        w = cm.propagate(W, pi0, 1.0)[1]
        spof = False
        for v in range(2, N):
            W2 = W.copy(); W2[v, :] = 0; W2[:, v] = 0
            if not reach(W2, 0, 1): spof = True; break
        X3.append(int(np.digitize(w, [0.35, 0.65]))); Xe.append(w); Sa.append(k >= 8); Sb.append(spof)
    X3, Xe, Sa, Sb = map(np.array, (X3, Xe, Sa, Sb))
    # mitigation: randomised response on the bin (true bin with prob 0.6, else uniform random bin)
    Xr = np.where(rng.random(len(X3)) < 0.6, X3, rng.integers(0, 3, len(X3)))
    Xx = np.zeros(len(X3), int)                                  # existence only
    qe = np.digitize(Xe, np.quantile(Xe, np.linspace(0, 1, 51)[1:-1]))
    half = n // 2
    def bayes(xtr, ytr, xte, yte):
        tab = {}
        for x, y in zip(xtr, ytr): tab.setdefault(int(x), []).append(y)
        maj = ytr.mean() >= 0.5
        pred = np.array([np.mean(tab[int(x)]) >= 0.5 if int(x) in tab else maj for x in xte])
        return float((pred == yte).mean())
    def mi(x, y):
        x = np.asarray(x); y = np.asarray(y).astype(int); m = 0.0
        for a in np.unique(x):
            for b in (0, 1):
                pxy = np.mean((x == a) & (y == b))
                if pxy > 0: m += pxy * np.log2(pxy / (np.mean(x == a) * np.mean(y == b)))
        return float(m)
    res = {}
    for sname, S in (("large internal estate", Sa), ("single internal point of failure", Sb)):
        base = float(max(S[half:].mean(), 1 - S[half:].mean()))
        res[sname] = dict(prevalence=float(S.mean()), majority_baseline=base,
                          acc_3bin=bayes(X3[:half], S[:half], X3[half:], S[half:]),
                          acc_randomised=bayes(Xr[:half], S[:half], Xr[half:], S[half:]),
                          acc_existence_only=bayes(Xx[:half], S[:half], Xx[half:], S[half:]),
                          mi_randomised_bits=mi(Xr, S),
                          acc_exact=bayes(qe[:half], S[:half], qe[half:], S[half:]),
                          mi_3bin_bits=mi(X3, S), mi_exact_bits=mi(qe, S),
                          entropy_bits=float(-(S.mean() * np.log2(S.mean()) + (1 - S.mean()) * np.log2(1 - S.mean()))))
    print(res, flush=True)
    json.dump(res, open(f"{OUT}/stress_E8_leakage.json", "w"), indent=1)
    return res


# ============================================================ E9 power
def run_E9():
    def power(n, d, a):
        df = n - 1; nc = d * np.sqrt(n); tc = tdist.ppf(1 - a / 2, df)
        return float(1 - nct.cdf(tc, df, nc) + nct.cdf(-tc, df, nc))
    res = {f"n={n}": dict(primary_alpha05=power(n, 0.75, 0.05), holm_strictest=power(n, 0.75, 0.05 / 6),
                          holm_last=power(n, 0.75, 0.05)) for n in (16, 20, 24, 26, 28)}
    need = next(n for n in range(10, 80) if power(n, 0.75, 0.05 / 6) >= 0.8)
    res["n_for_80pct_at_alpha_0.05_over_6"] = need
    print(res, flush=True)
    json.dump(res, open(f"{OUT}/stress_E9_power.json", "w"), indent=1)
    return res


if __name__ == "__main__":
    run_E9(); run_E8(); run_E6b(); run_E6c(); run_E7(); run_E6(n_inst=300)
